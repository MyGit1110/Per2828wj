package com.perchance.app;
import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class KeepAliveService extends Service {
 private PowerManager.WakeLock wl;
 @Override public void onCreate(){ super.onCreate();
  NotificationManager nm = getSystemService(NotificationManager.class);
  if (android.os.Build.VERSION.SDK_INT >= 26) { NotificationChannel ch = new NotificationChannel("keep", "Фон", NotificationManager.IMPORTANCE_LOW); nm.createNotificationChannel(ch); }
  Notification n = new NotificationCompat.Builder(this, "keep").setContentTitle("Стр открыта в фоне").setContentText("Мост TG работает").setSmallIcon(android.R.drawable.stat_sys_download_done).build();
  startForeground(11, n);
  try { PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE); wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "apk:keep"); wl.acquire(); } catch(Exception e){} }
 @Override public int onStartCommand(Intent i, int f, int id){ return START_STICKY; }
 @Override public void onDestroy(){ try { if (wl != null && wl.isHeld()) wl.release(); } catch(Exception e){} super.onDestroy(); }
 @Override public IBinder onBind(Intent i){ return null; } }
