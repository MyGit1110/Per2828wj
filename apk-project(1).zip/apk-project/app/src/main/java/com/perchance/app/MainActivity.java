package com.perchance.app;
import android.app.*;
import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
 private WebView wv;
 public static final String APP_URL = "https://04f1a4119d30b5672a3e08fddd12fce4.perchance.org/ai-character-chat";
 @Override protected void onCreate(Bundle b) {
  super.onCreate(b);
  setContentView(R.layout.activity_main);
  wv = findViewById(R.id.wv);
  WebSettings s = wv.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setMediaPlaybackRequiresUserGesture(false);
  s.setAllowFileAccess(true);
  wv.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ String u = r.getUrl().toString(); if (u.startsWith("http")) { v.loadUrl(u); return true; } try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch(Exception e){} return true; } });
  wv.setWebChromeClient(new WebChromeClient(){ @Override public void onReceivedTitle(WebView v, String t){ setTitle(t); } });
  wv.addJavascriptInterface(new Bridge(), "AndroidBridge");
  if (Build.VERSION.SDK_INT >= 33) { if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1); }
  startForegroundService();
  if (b == null) wv.loadUrl(APP_URL); else wv.restoreState(b);
 }
 private void startForegroundService(){ try { Intent i = new Intent(this, KeepAliveService.class); if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i); } catch(Exception e){} }
 @Override protected void onSaveInstanceState(Bundle o){ super.onSaveInstanceState(o); if (wv != null) wv.saveState(o); }
 @Override public void onBackPressed(){ if (wv != null && wv.canGoBack()) wv.goBack(); else super.onBackPressed(); }
 class Bridge { @JavascriptInterface public void onMessage(String json){ } @JavascriptInterface public String getPairCode(){ return ""; } }
}
