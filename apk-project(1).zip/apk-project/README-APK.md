# Как получить APK (3 способа)

App: ai-character-chat
URL: https://04f1a4119d30b5672a3e08fddd12fce4.perchance.org/ai-character-chat
Package: com.perchance.app

## Способ 1 — облако без Android Studio (рекомендую)
1. Создай репозиторий на GitHub, загрузи сюда ВСЕ файлы проекта.
2. Открой вкладку Actions → build-apk → скачай `app-debug-apk`.
3. Установи на телефон (разреши «неизвестные источники»).

## Способ 2 — PWABuilder (ещё проще, но это TWA)
1. Выложи стр. на https (у тебя уже https).
2. Открой https://www.pwabuilder.com → вставь URL стр. → Android → Download.
3. Фон-держатель там слабее: оставь ForegroundService из этого проекта, если нужен жёсткий фон.

## Способ 3 — Android Studio
1. Open Project → эта папка → Run на телефоне / Build → Build APK.
2. Подпиши release-ключом перед публикацией в Google Play.

Фон: MainActivity стартует KeepAliveService (foreground + WakeLock + иконка «Стр открыта в фоне»).
Автозапуск после перезагрузки: BootReceiver.
